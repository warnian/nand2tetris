project 11 readme



#SYMBOL TABLE NOT WORKING <=-------big concern ### seems to be working now monday 6/10 11:15am
#something going on with class level symbol table
#EXPRESSION LIST NOT STOPPING CORRECTLY #think its solved 6/10 3:02 pm
#Compile let functioning for now
#while not working #### FIXED as of 6/11 1:58 PM
#if not working maybe related to while ###### fixed as of 6/11 1:58 PM

#succesfully compiles:
Seven: #completed
    Main
ConvertTobin: #completed
    Main
Square:
    Main
    Square
    SquareGame
Average:
    #problem with stopping at /s in string #fixed 11:13 am 6/13

    #problem handling a[i] let getting hung up on a[i]